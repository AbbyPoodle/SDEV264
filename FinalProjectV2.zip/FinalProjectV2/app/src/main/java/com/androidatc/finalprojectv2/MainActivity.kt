package com.androidatc.finalprojectv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.androidatc.finalprojectv2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var btnSend : Button
    private lateinit var inputMass : EditText
    private lateinit var inputVolume : EditText
    private lateinit var binding: ActivityMainBinding
    private lateinit var massUnit: TextView
    private lateinit var volUnit: TextView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        val reagent= binding.mass.text
        val solvent=binding.volume.text
        val molWeight = binding.molecularweight.text

        btnSend = findViewById(R.id.calculate)
        inputMass = findViewById(R.id.mass)
        inputVolume = findViewById(R.id.volume)
        massUnit = findViewById(R.id.massUnitTxt)
        volUnit = findViewById(R.id.volUnitTxt)


        //units selected under Preferences tab
        var massUnitSelected = intent.getStringExtra("massUnitClicked")
        massUnit.text = massUnitSelected

        val volUnitSelected = intent.getStringExtra("volUnitClicked")
        volUnit.text = volUnitSelected


        // preferences and help buttons
        val clickPreferences: TextView = findViewById(R.id.Preferences)
        clickPreferences.setOnClickListener {
            val intent = Intent(this, Preferences::class.java)
            startActivity(intent)
        }

        val clickHelp: TextView = findViewById(R.id.Help)
        clickHelp.setOnClickListener {
            val intent = Intent(this, Help::class.java)
            startActivity(intent)
        }
        //calculate result
        btnSend.setOnClickListener {
            var sumResult = "0"

            //ok
            when {massUnitSelected == "grams" && volUnitSelected == "liters" -> sumResult =
                ((reagent.toString().toDouble()/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString())
            }
            //ok
            when {massUnitSelected == "milligrams" && volUnitSelected == "milliliters" -> sumResult =
                ((reagent.toString().toDouble()/1000)/(molWeight.toString().toDouble() * (solvent.toString().toDouble()/1000))).toString()
            }
            //ok
            when {volUnitSelected == "milliliters" && massUnitSelected == "" -> sumResult =
                ((reagent.toString().toDouble()/(molWeight.toString().toDouble() * (solvent.toString().toDouble()/1000))).toString())
            }
            //ok
            when {massUnitSelected == "grams" -> sumResult =
                (reagent.toString().toDouble()/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString()
            }
            //ok
            when {volUnitSelected == "liters" && massUnitSelected == ""-> sumResult =
                ((reagent.toString().toDouble()/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString())
            }
            //ok
            when {volUnitSelected == "" && massUnitSelected == ""-> sumResult =
                ((reagent.toString().toDouble()/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString())
            }
            //ok
            when {massUnitSelected == "milligrams" && volUnitSelected == "liters" -> sumResult =
                ((reagent.toString().toDouble()/1000)/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString()
            }
            //ok
            when {massUnitSelected == "milligrams" && volUnitSelected == ""-> sumResult =
                ((reagent.toString().toDouble()/1000)/(molWeight.toString().toDouble() * solvent.toString().toDouble())).toString()
            }
            //ok
            when {massUnitSelected == "grams" && volUnitSelected == "milliliters" -> sumResult =
                (reagent.toString().toDouble()/(molWeight.toString().toDouble() * (solvent.toString().toDouble()/1000))).toString()
            }


            startActivity(
                Intent(this,activity_2::class.java)
                    .putExtra("mass",inputMass.text.toString())
                    .putExtra("volUnitMain",volUnit.text.toString())
                    .putExtra("massUnitMain",massUnit.text.toString())
                    .putExtra("volume",inputVolume.text.toString())
                    .putExtra("result", sumResult.toString())
                    )

        }

    }
}