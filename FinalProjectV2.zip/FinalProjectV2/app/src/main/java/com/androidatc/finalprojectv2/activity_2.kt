package com.androidatc.finalprojectv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class activity_2 : AppCompatActivity() {

    private lateinit var textMass: TextView
    private lateinit var textVolume: TextView
    private lateinit var textResult: TextView
    private lateinit var massUnit2: TextView
    private lateinit var volUnit2: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)


        textMass = findViewById(R.id.massId)
        textVolume = findViewById(R.id.volumeId)
        massUnit2 = findViewById(R.id.massUnit2)
        volUnit2 = findViewById(R.id.volUnit2)

        textResult = findViewById(R.id.concentrationId)

        val mass = intent.getStringExtra("mass")
        textMass.text = mass

        val volume = intent.getStringExtra("volume")
        textVolume.text = volume

        val result = intent.getStringExtra("result")
        textResult.text = result

        val massUnitSelected2 = intent.getStringExtra("massUnitMain")
        massUnit2.text = massUnitSelected2

        val volUnitSelected2 = intent.getStringExtra("volUnitMain")
        volUnit2.text = volUnitSelected2

        val secondActbutton = findViewById<Button>(R.id.button)
        secondActbutton.setOnClickListener {
            val Intent = Intent(this,MainActivity::class.java)
            startActivity(Intent)
        }

    }

}