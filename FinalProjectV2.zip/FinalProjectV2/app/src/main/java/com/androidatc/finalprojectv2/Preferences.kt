package com.androidatc.finalprojectv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView

class Preferences : AppCompatActivity() {

    lateinit var massUnit: TextView
    lateinit var volUnit: TextView

    fun onSelect(view: View){
        if (findViewById<RadioButton>(R.id.gramsRB).isChecked)findViewById<TextView>(R.id.massTV).text="grams"
        if (findViewById<RadioButton>(R.id.milligramsRB).isChecked)findViewById<TextView>(R.id.massTV).text="milligrams"

        if (findViewById<RadioButton>(R.id.litersRB).isChecked)findViewById<TextView>(R.id.volTV).text="liters"
        if (findViewById<RadioButton>(R.id.millilitersRB).isChecked)findViewById<TextView>(R.id.volTV).text="milliliters"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        val btnSendPreferences = findViewById<Button>(R.id.savePreferences)
        massUnit = findViewById(R.id.massTV)
        volUnit = findViewById(R.id.volTV)

        btnSendPreferences.setOnClickListener {
            startActivity(
                Intent(this,MainActivity::class.java)
                .putExtra("massUnitClicked",massUnit.text.toString())
                .putExtra("volUnitClicked",volUnit.text.toString()))
        }
    }
}
